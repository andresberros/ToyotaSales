﻿using Microsoft.AspNetCore.Mvc;

namespace Datacomp.NewCarSmell.Poc.Controllers
{
    [Route("Test")]
    public class TestController: Controller
    {
        [HttpGet]
        public ActionResult<string> Test()
        {
            return "Hello peterh, test";
        }
        
    }
}
