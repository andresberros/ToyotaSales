
export * from './emotion-analyser';