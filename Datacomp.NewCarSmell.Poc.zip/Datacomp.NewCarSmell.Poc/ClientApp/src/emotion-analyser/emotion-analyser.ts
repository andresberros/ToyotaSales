
import {EmotionApiResult, Emotions} from '../service/emotion-api-service';


export interface EmotionAnalysisResult {
	Qpos: number;
	Qneutral: number;
	Qneg: number;
}

const Wpos = 2;
const Wneural = 0.01;
const Wneg = 2;

export class EmotionAnalyser {

	private emotion: Emotions;

	constructor (face: EmotionApiResult) {
		this.emotion = face.faceAttributes.emotion;
	}

	public analyse(): EmotionAnalysisResult {
		return {
			Qpos: this.Qpos,
			Qneg: this.Qneg,
			Qneutral: this.Qneutral
		};
	}

	private get Qneg() {
		const {anger, contempt, sadness, fear, disgust} = this.emotion; 
		return ((anger + contempt + sadness + fear + disgust) / 5) * Wneg;
	}

	private get Qpos() {
		const {happiness, surprise} = this.emotion;
		return ((happiness + surprise) / 2) * Wpos;
	}

	private get Qneutral() {
		return this.emotion.neutral * Wneural;
	}

}