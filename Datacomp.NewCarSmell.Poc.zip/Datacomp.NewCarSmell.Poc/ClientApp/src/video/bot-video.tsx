
import * as React from 'react';

export class BotVideo extends React.Component {

	componentDidMount() {
		const vid: HTMLVideoElement = document.querySelector("#fiachravid");
	}

	render() {
		return (
			<div className='bot-video-wrapper'>
				<h1>React Player</h1>
				<video id="fiachravid">
					<source src={"/fiachravid.mp4"} type={"video/mp4"}></source>
				</video>
			</div>
		)
	}
}