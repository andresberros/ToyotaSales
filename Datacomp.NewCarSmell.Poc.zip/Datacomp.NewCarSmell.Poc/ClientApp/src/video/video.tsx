
import * as React from 'react';
import * as Webcam from 'react-webcam';

import { EmotionApiService, EmotionApiResult } from '../service/emotion-api-service';
import { EmotionAnalysisResult, EmotionAnalyser } from '../emotion-analyser';

//turn this to false if you want to use a manual switch
const pollCamera: boolean = true;

// 3000 is bare minimum to avoid burning api calls
const pollingInterval: number = 3000; //milliseconds

interface VideoState {
	emotion: string;
}

export class Video extends React.Component<{}, VideoState> {

	private webcam: Webcam;
	private emotionAnalysis: EmotionAnalysisResult;

	constructor() {
		super({});
		this.state = { emotion: '' };
	}

	setRef = (webcam: Webcam) => {
		this.webcam = webcam;
	}

	componentDidMount() {
		if (pollCamera) {
			this.doCapture();
		}
	}

	private doCapture = () => {
		setInterval(() => {
			this.capture();
		}, pollingInterval)
	}

	private getMainEmotionFrom(res: Array<EmotionApiResult>): string {
		try {
			if (res.length === 0) return 'Data unknown';
			const first = res[0]; //only one face, for now
			const emotions = first.faceAttributes.emotion;
			const mainEmotion: string = Object.keys(emotions).reduce((a, b) => emotions[a] - emotions[b] ? a : b);
			return mainEmotion;
		}
		catch (ex) {
			return 'unknown';
		}
	}

	capture = () => {
		const imageSrc: string = this.webcam.getScreenshot() || '';
		console.log(imageSrc);
		const svc = new EmotionApiService();

		svc.doPost(imageSrc).then(res => {
			const mainEmotion = this.getMainEmotionFrom(res);
			if (res && res[0]) {
				this.emotionAnalysis = new EmotionAnalyser(res[0]).analyse();
				this.setState({ emotion: mainEmotion });
			}
		})
	};

	private renderAnalysis() {
		const happyReading = this.emotionAnalysis ? this.emotionAnalysis.Qpos * 100 : 0;
		const sadReading = this.emotionAnalysis ? this.emotionAnalysis.Qneg * 800 : 0;
		const neutralReading = this.emotionAnalysis ? this.emotionAnalysis.Qneutral * 1000 : 0;

		return (
			<div className='emotions-wrapper'>
				<progress className='progress-bar' id="progress-happy" max={100} value={happyReading}></progress>
				<br />
				<progress className='progress-bar' id="progress-sad" max={100} value={sadReading}></progress>
				<br />
				<progress className='progress-bar' id="progress-neutral" max={100} value={neutralReading}></progress>
				<br />
			</div>
		)
	}

	private renderButton() {
		if (pollCamera) return null;
		return (
			<button onClick={this.capture}>Capture photo</button>
		);
	}

	render() {
		return (
			<div className="right-corner">
				<Webcam
					audio={false}
					height={350}
					ref={this.setRef}
					screenshotFormat="image/jpeg"
					width={350}
				/>

				{this.renderButton()}
				{this.renderAnalysis()}
			</div>
		);
	}

}
