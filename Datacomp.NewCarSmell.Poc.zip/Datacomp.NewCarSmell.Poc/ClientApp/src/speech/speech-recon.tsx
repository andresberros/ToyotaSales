import * as React from 'react'
const { webkitSpeechRecognition } = (window as any);
var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;
let recognition = new SpeechRecognition();
let currentFace = null;
let recognizing = false;

function setupRecognition(lang: string) {
    recognition.lang = lang;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;
}

function playVideo(speechText: string) {
    let vid: HTMLVideoElement = document.querySelector("#fiachravid");
    switch (speechText) {
        case "hi there":
            vid.src = "fiachravid.mp4#t=0,3";
            vid.play();
            break;
        case "not well very stressed":
            vid.src = "fiachravid.mp4#t=3.5,6.5";
            vid.play();
            break;
        case "i'm great actually":
            vid.src = "fiachravid.mp4#t=6.6,9.5";
            vid.play();
            break;
        default:
            vid.src = "fiachravid.mp4#t=9.6,10";
            vid.play();
            break;
    }
}

function startListening(lang: string) {
    if (recognizing) {
        recognition = new SpeechRecognition();
        setupRecognition(lang);
    } else {
        recognition.lang = lang;
    }

    recognition.start();
}

function GetFaceSrc(sentiment: number) {

    if (!sentiment) {
        return <small>.</small>
    }

    if (sentiment < -0.2) {
        return <img className="sentiment-face" src={"/sad-face.png"} />;
    } else if (sentiment > 0.2) {
        return <img className="sentiment-face" src={"/happy-face.png"} />;
    } else {
        return <img className="sentiment-face" src={"/neutral-face.png"} />;
    }
}

interface SpeechInterface {
    sentimentScore: number;
    showLoader: boolean;
}

export class Speech extends React.Component<{}, SpeechInterface> {

    constructor() {
        super({});
        this.state = { sentimentScore: 0, showLoader: false };
    }

    componentDidMount() {
        setupRecognition("en-US");

        recognition.onresult = (event) => {
            const speechResult = event.results[0][0].transcript;
            const textSentimentUrl = "https://us-central1-datacomp18-ex-team-3.cloudfunctions.net/convertSpeechViaHttp";
            this.setState({ showLoader: true });
            fetch(textSentimentUrl, {
                method: 'post',
                headers: {
                    "Content-type": "application/json"
                },
                body: JSON.stringify({ audioBytes: "abc", transcript: speechResult })
            }).then((response) => {
                if (response.ok) {
                    return response.json();
                }
            }).then((data) => {
                this.setState({ sentimentScore: data.sentimentScore, showLoader: false });
                playVideo(data.translation.toLowerCase());
            }).catch(err => {
                console.error(err);
                this.setState({ showLoader: false });
            });
        }

        recognition.onend = function (event) {
            recognizing = false;
        }

        recognition.onstart = function (event) {
            console.log('SpeechRecognition.onstart');
            recognizing = true;
        }
    }

    render() {
        return <div>
            <video id="fiachravid" width={"50%"}>
                <source src={"/fiachravid.mp4"} type={"video/mp4"}></source>
            </video>

            <br />
            {GetFaceSrc(this.state.sentimentScore)}

            <br />
            
            <button onClick={() => { startListening("en-US") }} >English</button>
            <button id="spanish-button" onClick={() => { startListening("es-ES") }} >Spanish</button>
            <button id="hindi-button" onClick={() => { startListening("hi-IN") }} >Hindi</button>
            <br />

            {this.state.showLoader && <img className="loader" height="50px" src="/loader.gif" alt="" />}
        </div>
    }
}