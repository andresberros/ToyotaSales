

import * as React from 'react';
import {ReactMic} from 'react-mic';
import { GoogleApiService } from '../service/google-api-service';



interface MicState {
	record: boolean
}

const samplingRate = 5000;

export class Mic extends React.Component<{}, MicState> {

	constructor(props: any) {
		super({});
		this.state = {
			record: true
		};
	}

	

	startRecording = () => {
		this.setState({
		  record: true
		});
	}

	stopRecording = () => {
		this.setState({
		  record: false
		});
	}

	onData(recordedBlob: Blob) {
		console.log('chunk of real-time data is: ', recordedBlob);
		// setTimeout(() =>{
		// 	new GoogleApiService().post(recordedBlob).then(resp => {
		// 	console.log(resp);
		// 	})
		// 	.catch(err => {
		// 		console.warn(err);
		// 	})
		// }, 2000)
		
	}

	onStop(recordedBlob: Blob) {
		console.log('recordedBlob is: ', recordedBlob);
		new GoogleApiService().post(recordedBlob).then(resp => {
			console.log(resp);
			})
			.catch(err => {
				console.warn(err);
			})
	}

	render() {
	return (
	  <div>
	    <ReactMic
	      record={this.state.record}
	      onStop={this.onStop}
	      onData={this.onData}
	      />
      {/* <button onClick={this.startRecording} type="button">Start</button>
      <button onClick={this.stopRecording} type="button">Stop</button> */}

	  </div>
	);
	}
}