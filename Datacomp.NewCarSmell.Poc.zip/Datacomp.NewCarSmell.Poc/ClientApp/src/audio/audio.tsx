
import * as React from 'react';


export class Audio extends React.Component {

	public render() {
		return null;
	}
}