

import * as Recast from 'recastai';

const token = '0f7b4de1156793caf689efb06d462509';

export class RecastService {

	public async analyse(text: string) {
		try {
			const conn = new Recast.default(token, 'en');
			const res = await conn.request.analyseText(text);
	        return res;
		}
		catch(ex) {
			return '';
		}
		
	}

}