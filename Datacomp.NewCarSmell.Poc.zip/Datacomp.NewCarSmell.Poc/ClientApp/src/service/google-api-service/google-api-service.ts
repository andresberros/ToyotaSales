
//import {blobToBase64} from 'blob-to-base64';


const endpoint = 'https://us-central1-datacomp18-ex-team-3.cloudfunctions.net/convertSpeechViaHttp';


export class GoogleApiService {

	public post(data: Blob): Promise<any> {

		return new Promise<any>((resolve, reject) => {
			
			const request = new XMLHttpRequest();
			//const payload = this.buildPayload(base64EncodedImage);

			request.onload = function (response: any) {
				resolve(response);
			};

			request.onerror = function (ex?: any) {
				reject(new Error('XMLHttpRequest Error'));
			};

			request.open('POST', endpoint);

			// sorry for the copy paste ;)

			request.setRequestHeader('Access-Control-Allow-Origin', '*');
			request.setRequestHeader('content-type', 'application/json');

			

		});
	}
}




