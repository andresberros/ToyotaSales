
import {makeblob} from './make-blob';

import {ResultProcessor, EmotionApiResult} from './result-processor';



export class EmotionApiService {

	private static apiEndPoint: string = 'http://10.120.69.200:8000/api';

	public postImage(base64EncodedImage: string): Promise<any> {
		return new Promise<any>((resolve, reject) => {
			
			const request = new XMLHttpRequest();
			//const payload = this.buildPayload(base64EncodedImage);

			request.onload = function (response: any) {
				resolve(response);
			};

			request.onerror = function (ex?: any) {
				reject(new Error('XMLHttpRequest Error'));
			};

			request.open('POST', EmotionApiService.apiEndPoint + '/face');

			// sorry for the copy paste ;)

			request.setRequestHeader('Access-Control-Allow-Origin', '*');
			request.setRequestHeader('content-type', 'application/octet-stream');


			request.send(makeblob(base64EncodedImage));
		});
	}

	/*
	*  A basic GET call to check the functioning of API
	*/

	public dummyGet() {
		return new Promise<any>((resolve, reject) => {
			const request = new XMLHttpRequest();

			request.onload = function (response) {
				resolve(response);
			};

			request.onerror = function (ex?: any) {
				reject(new Error('XMLHttpRequest Error'));
			};

			request.open('GET', 'http://10.120.69.200:8000/api/Face/200​');
			request.setRequestHeader('Access-Control-Allow-Origin', '*');
			request.setRequestHeader('content-type', 'text/json');
			//"content-type": "application/json; charset=utf-8",
			request.send();
		});
	}

	public doPost(base64img: string): Promise<Array<EmotionApiResult>> {
		var subscriptionKey = "192a698b19244a349e4603f40ea43242";

        
        var uriBase =
            "https://westcentralus.api.cognitive.microsoft.com/face/v1.0/detect";

        return new Promise<any>((resolve, reject) => {
			
			const request = new XMLHttpRequest();
			//const payload = this.buildPayload(base64EncodedImage);

			request.onload = function (response: any) {
				const resp = new ResultProcessor(response).process();
				resolve(resp);
			};

			request.onerror = function (ex?: any) {
				reject(new Error('XMLHttpRequest Error'));
			};

			request.open('POST', uriBase + '?returnFaceAttributes=smile,emotion');

			// sorry for the copy paste ;)

			request.setRequestHeader('Access-Control-Allow-Origin', '*');
			request.setRequestHeader('content-type', 'application/octet-stream');
			request.setRequestHeader("Ocp-Apim-Subscription-Key", subscriptionKey);

			request.send(makeblob(base64img));
			console.log("this is the blob text now");
			console.log(makeblob(base64img));
		});

	}


}