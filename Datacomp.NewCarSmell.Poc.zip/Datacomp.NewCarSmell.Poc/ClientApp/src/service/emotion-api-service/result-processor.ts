

export interface EmotionApiResult {
	faceAttributes: FaceAttributes;
}

interface FaceAttributes {
	emotion: Emotions;
}

export interface Emotions {
	anger: number; 
	contempt: number; 
	disgust: number; 
	fear: number; 
	happiness: number; 
	neutral: number; 
	sadness: number; 
	surprise: number;
}

export class ResultProcessor {

	constructor(private response: any) {}

	public process() {
		//
		if (this.response && this.response.currentTarget && this.response.currentTarget.response) {
			try {
				const result: Array<EmotionApiResult> = JSON.parse(this.response.currentTarget.response)
				return result;
			}
			catch(ex){
				return [];
			}
		}

		return [];
	}

}