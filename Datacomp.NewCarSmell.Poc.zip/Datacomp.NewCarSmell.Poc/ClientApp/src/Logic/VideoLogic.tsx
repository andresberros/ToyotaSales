function ping(text: string) {
    return `Pinging ${text}`;
}

export default ping
    

